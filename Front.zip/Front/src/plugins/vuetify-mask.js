import Vue from "vue";
import VuetifyMask from "vuetify-mask";
Vue.use(VuetifyMask);
export default VuetifyMask;